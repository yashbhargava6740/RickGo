package com.example.homepage;

import static android.content.ContentValues.TAG;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class loginForm extends AppCompatActivity {

    FirebaseFirestore db;
    MaterialButton login;
    TextInputLayout userid, pass;
    //private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_login_form);
        //Hooks
        db = FirebaseFirestore.getInstance();
        login = (MaterialButton) findViewById(R.id.loginbtn);
        userid = findViewById(R.id.userid);
        pass = findViewById(R.id.password);
        //mAuth = FirebaseAuth.getInstance();
    }

    public void loginMan(android.view.View view) {
        String uid = userid.getEditText().getText().toString();
        String password = pass.getEditText().getText().toString();
        db.collection("driver").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot QS) {
                boolean flag = false;
                if(QS.isEmpty()) {
                    Log.d(TAG, "No Data Found");
                    return;
                }
                else {
                    for(QueryDocumentSnapshot qds : QS) {
                        Driver D = qds.toObject(Driver.class);
                        if ((D.getId()).equals(uid) && (D.getPassword()).equals(password)) {
                            Log.d(TAG, "User Found");
                            flag = true;
                            Toast.makeText(loginForm.this, "Login SuccessFull", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(loginForm.this,loggedIn.class);
                            intent.putExtra("UserID", uid);
                            startActivity(intent);
                            finish();
                            break;
                        }
                    }
                    if(flag == false) {
                        Log.d(TAG, "User Not Found");
                        Toast.makeText(loginForm.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.w(TAG, "Error Getting Data",e);
            }
        });
    }
}