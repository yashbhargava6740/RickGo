package com.example.homepage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BookRikshaw extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_rikshaw);
    }
}