package com.example.homepage;

public class Driver {
    private String name;
    private String id;
    private String password;
    private String phone;

    public Driver() {
        name = null;
        id = null;
        password = null;
        phone = null;
    }
    public Driver(String name, String id, String password, String phone) {
        this.name = name;
        this.id = id;
        this.password = password;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }
    public String getPhone() {
        return phone;
    }
    public String getPassword() {
        return password;
    }
    public String getId() {
        return id;
    }
}