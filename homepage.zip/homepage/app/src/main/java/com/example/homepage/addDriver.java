package com.example.homepage;

import static android.content.ContentValues.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.core.view.View;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;
import com.example.homepage.Driver;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

public class addDriver extends AppCompatActivity {
    FirebaseFirestore rootNode;
    TextInputLayout drivername, driverId, driverPassword, driverPhone;
    MaterialButton addDet;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_add_driver);

        addDet = findViewById(R.id.driverbtn);      // Button
        drivername = findViewById(R.id.drivername);
        driverId = findViewById(R.id.driverid);
        driverPassword = findViewById(R.id.driverpass);
        driverPhone = findViewById(R.id.phoneno);
    }
    // Validations are left to be applied....

//    private Boolean validateName() {
//        String val = drivername.getEditText().getText().toString();
//        if(val.isEmpty()) {
//            drivername.setError("Field cannot be empty");
//            return false;
//        }
//        else {
//            drivername.setError(null);
//            drivername.setErrorEnabled(false);
//            return true;
//        }
//    }
//
//    private Boolean validateId() {
//        String val = driverId.getEditText().getText().toString();
//        String nowhitespace = "(?=\\S+$)";
//        if(val.isEmpty()) {
//            driverId.setError("Field cannot be empty");
//            return false;
//        }
//        else if(!val.matches(nowhitespace)) {
//            driverId.setError("Id Cannot Contain Spaces");
//            return false;
//        }
//        else {
//            driverId.setError(null);
//            driverId.setErrorEnabled(false);
//            return true;
//        }
//    }
//
//    private Boolean validatePassword() {
//        String val = driverPassword.getEditText().getText().toString();
//        if(val.isEmpty()) {
//            driverPassword.setError("Field cannot be empty");
//            return false;
//        }
//        else {
//            driverPassword.setError(null);
//            driverPassword.setErrorEnabled(false);
//            return true;
//        }
//    }
//
//    private Boolean validatePhone() {
//        String val = driverPhone.getEditText().getText().toString();
//        if(val.isEmpty()) {
//            driverPhone.setError("Field cannot be empty");
//            return false;
//        }
//        else if (val.length() != 10) {
//            driverPhone.setError("Phone number can be of 10 digits");
//            return false;
//        }
//        else {
//            driverPhone.setError(null);
//            driverPhone.setErrorEnabled(false);
//            return true;
//        }
//    }

    public boolean alreadyFound(Driver D,String id, String pass) {
        final boolean[] flag = {false};
        rootNode.collection("driver").get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot QS) {

                if(QS.isEmpty()) {
                    return;
                }
                else {
                    for(QueryDocumentSnapshot qds : QS) {
                        Driver D = qds.toObject(Driver.class);
                        if ((D.getId()).equals(id) || (D.getPassword()).equals(pass)) {
                            Log.d(TAG, "User Already Present");
                            flag[0] = true;
                            break;
                        }
                    }
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.w(TAG, "Error Getting Data",e);
            }
        });
        if(flag[0] == true) return false;
        return true;
    }
    public void regDriver(android.view.View v) {
        String name = drivername.getEditText().getText().toString();
        String id = driverId.getEditText().getText().toString();
        String pass = driverPassword.getEditText().getText().toString();
        String phone = driverPhone.getEditText().getText().toString();

        //if(!validateName() || !validateId() || !validatePhone() || !validatePassword()) return;
        rootNode = FirebaseFirestore.getInstance();
        Driver D = new Driver(name, id, pass, phone);
        if (alreadyFound(D,id,pass)) {
            Toast.makeText(this, "Already Registered, Login", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this, loginForm.class);
            startActivity(intent);
            finish();
        } else {
            rootNode.collection("driver")
                    .add(D)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            Log.d(TAG, "Driver Added With ID" + documentReference.getId());
                            Toast.makeText(addDriver.this, "New Driver Added", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Log.w(TAG, "Error Adding Data", e);
                            Toast.makeText(addDriver.this, "Error Loading Data", Toast.LENGTH_SHORT).show();
                        }
                    });
        }

    }
}