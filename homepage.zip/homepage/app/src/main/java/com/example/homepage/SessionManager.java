package com.example.homepage;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashMap;


public class SessionManager {
    SharedPreferences sharedPreferences;
    public SharedPreferences.Editor editor;
    public Context context;
    int PRIVATE_MODE = 0;

    private static final String USER_ID = "USER_ID";
    private static final String LOGIN = "IS_LOGIN";
    private static final String PREF_NAME = "LOGIN";
    private static final String USER_PHONE = "USER_PHONE";
    private static final String USER_NAME = "USER_NAME";


    public SessionManager(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = sharedPreferences.edit();
    }

    public void createSession(String user_id, String user_phone, String user_name) {
        editor.putBoolean(LOGIN, true);
        editor.putString(USER_ID, user_id);
        editor.putString(USER_PHONE, user_phone);
        editor.putString(USER_NAME, user_name);
        editor.apply();
    }
    public boolean isLogin() {
        return sharedPreferences.getBoolean(LOGIN,false);
    }

    public HashMap<String, String> getUserDetails() {
        HashMap<String,String> hm = new HashMap<>();
        hm.put(USER_ID, sharedPreferences.getString(USER_ID,null));
        hm.put(USER_PHONE, sharedPreferences.getString(USER_PHONE,null));
        hm.put(USER_NAME, sharedPreferences.getString(USER_NAME,null));
        return hm;
    }
}
